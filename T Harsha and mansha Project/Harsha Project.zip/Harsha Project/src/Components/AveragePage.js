import React from "react";

const AveragePage = () => {
  return <div>AveragePage</div>;
};
export default AveragePage;
