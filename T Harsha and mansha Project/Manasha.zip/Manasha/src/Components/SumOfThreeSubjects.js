import React from "react";

const SumOfThreeSubjects = () => {
  return <div>SumOfThreeSubjects</div>;
};
export default SumOfThreeSubjects;
